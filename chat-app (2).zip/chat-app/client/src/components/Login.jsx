import React, {useState} from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

export default function Login(){
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('username', res.data.username);
      nav('/');
    } catch (err) {
      setErr(err?.response?.data?.msg || 'Login failed');
    }
  };

  return (
    <div style={{maxWidth:400,margin:'50px auto'}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input value={username} onChange={e=>setUsername(e.target.value)} placeholder='username' required />
        <br/>
        <input type='password' value={password} onChange={e=>setPassword(e.target.value)} placeholder='password' required />
        <br/>
        <button type='submit'>Login</button>
      </form>
      <p style={{color:'red'}}>{err}</p>
      <p>Don't have an account? <Link to='/signup'>Sign up</Link></p>
    </div>
  );
}
