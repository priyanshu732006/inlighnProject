import React, {useState} from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

export default function Signup(){
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const [err,setErr]=useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/auth/signup', { username, password });
      nav('/login');
    } catch (err) {
      setErr(err?.response?.data?.msg || 'Signup failed');
    }
  };

  return (
    <div style={{maxWidth:400,margin:'50px auto'}}>
      <h2>Sign up</h2>
      <form onSubmit={submit}>
        <input value={username} onChange={e=>setUsername(e.target.value)} placeholder='username' required />
        <br/>
        <input type='password' value={password} onChange={e=>setPassword(e.target.value)} placeholder='password (min 6)' required />
        <br/>
        <button type='submit'>Create account</button>
      </form>
      <p style={{color:'red'}}>{err}</p>
      <p>Already have an account? <Link to='/login'>Login</Link></p>
    </div>
  );
}
