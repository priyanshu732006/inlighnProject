import React, {useEffect, useState, useRef} from 'react';
import { io } from 'socket.io-client';

export default function ChatPage(){
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [online, setOnline] = useState([]);
  const [typing, setTyping] = useState('');
  const socketRef = useRef();

  useEffect(()=> {
    const username = localStorage.getItem('username') || 'Anonymous';
    socketRef.current = io('http://localhost:5000');
    const socket = socketRef.current;

    socket.on('connect', ()=> {
      socket.emit('register', username);
    });

    socket.on('loadMessages', (msgs)=> setMessages(msgs));
    socket.on('chatMessage', (m) => setMessages(prev => [...prev, m]));
    socket.on('onlineUsers', (list) => setOnline(list));
    socket.on('typing', (user) => setTyping(user));

    return ()=> socket.disconnect();
  }, []);

  const send = () => {
    if (!input) return;
    const payload = { sender: localStorage.getItem('username') || 'You', text: input };
    socketRef.current.emit('chatMessage', payload);
    setInput('');
  };

  const onTyping = () => {
    socketRef.current.emit('typing', localStorage.getItem('username') || 'Someone');
  };

  return (
    <div style={{display:'flex',height:'100vh'}}>
      <div style={{width:250, borderRight:'1px solid #ccc', padding:10}}>
        <h3>Online</h3>
        <ul>
          {online.map((u,i)=><li key={i}>{u}</li>)}
        </ul>
        <hr/>
        <button onClick={()=>{localStorage.removeItem('token'); localStorage.removeItem('username'); window.location='/login'}}>Logout</button>
      </div>
      <div style={{flex:1,display:'flex',flexDirection:'column'}}>
        <div style={{flex:1, padding:10, overflowY:'auto'}}>
          {messages.map((m,i)=>(
            <div key={i} style={{margin:'8px 0'}}>
              <b>{m.sender}:</b> {m.text} <small style={{color:'#666'}}>({new Date(m.createdAt||m.createdAt).toLocaleTimeString()})</small>
            </div>
          ))}
        </div>
        <div style={{padding:10,borderTop:'1px solid #ccc'}}>
          <div>{typing ? `${typing} is typing...` : ''}</div>
          <input value={input} onChange={e=>{setInput(e.target.value); onTyping();}} placeholder='Type a message' style={{width:'70%'}} />
          <button onClick={send}>Send</button>
        </div>
      </div>
    </div>
  );
}
