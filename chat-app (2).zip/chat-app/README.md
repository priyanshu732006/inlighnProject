# Real-Time Chat App (Client + Server)

## Quick start

 
1. Start server:
   ```
   cd server
   npm install
   npm run dev
   ```
2. Start client:
   ```
   cd client
   npm install
   npm start
   ```
3. Open http://localhost:3000

Notes:
- Tokens are stored in localStorage (simple setup for testing). For production, use HTTP-only cookies.
- This app uses Socket.IO for real-time messaging and MongoDB for persistence.
