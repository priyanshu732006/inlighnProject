import { Server } from 'socket.io';
import Message from './models/Message.js';

export default function setupSocket(server) {
  const io = new Server(server, { cors: { origin: true }});
  const onlineUsers = new Map();

  io.on('connection', async (socket) => {
    console.log('Socket connected', socket.id);

    // send message history
    try {
      const msgs = await Message.find().sort({ createdAt: 1 }).limit(200);
      socket.emit('loadMessages', msgs);
    } catch (err) {
      console.error('Load messages failed', err);
    }

    socket.on('register', (username) => {
      onlineUsers.set(socket.id, username);
      io.emit('onlineUsers', Array.from(onlineUsers.values()));
    });

    socket.on('chatMessage', async (payload) => {
      try {
        const m = await Message.create({ sender: payload.sender, text: payload.text });
        io.emit('chatMessage', m);
      } catch (err) {
        console.error('Save message error', err);
      }
    });

    socket.on('typing', (username) => {
      socket.broadcast.emit('typing', username);
    });

    socket.on('disconnect', () => {
      onlineUsers.delete(socket.id);
      io.emit('onlineUsers', Array.from(onlineUsers.values()));
      console.log('Socket disconnected', socket.id);
    });
  });
}
