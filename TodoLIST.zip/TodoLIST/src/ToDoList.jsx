import { useState } from "react";

function ToDoList(){
    const[tasks,settask]=useState([])
    const[newtask,setnewtask]=useState("")

    const handleAddlist =()=>{
       if(newtask.trim()){
        const taskobject={
           id:new Date(),
           text:newtask,
           completed:false
        };
        settask([...tasks,taskobject])
        newtask("")
       }
    }
    const handleOnChange= (event)=>{
       setnewtask(event.target.value)
    }
    const handletogglecomple=(id)=>{
        
    }
}